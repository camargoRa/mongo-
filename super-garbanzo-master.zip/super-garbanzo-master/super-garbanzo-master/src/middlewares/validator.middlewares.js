export const validateSchema =(Shema) => (req, res, next) =>{
    try {
        Shema.parse(req.body);
        next();
    } catch (error) {
        return res
        .status(400)
        .json({error: error.error.map((error) => error.message) })
    }
}